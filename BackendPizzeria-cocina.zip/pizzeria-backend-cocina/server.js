// Backend del módulo COCINA: cola de pedidos, preparación, horno y listo.
const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// Configuración local opcional desde pizzeria-backend/.env (sin librerías adicionales).
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile)) {
    for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
        const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
        if (match && process.env[match[1]] === undefined) {
            process.env[match[1]] = match[2].replace(/^(['"])(.*)\1$/, '$2');
        }
    }
}

const app = express();
const PORT = Number(process.env.PORT || 3000);
app.use(express.json({ limit: '1mb' }));
app.use(cors());

// Conexión MySQL; las credenciales se configuran en .env y no se guardan en el código.
const db = mysql.createPool({
    host: process.env.DB_HOST || '127.0.0.1',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'pizzeria_db',
    port: Number(process.env.DB_PORT || 3306),
    waitForConnections: true,
    connectionLimit: 10,
    decimalNumbers: true
});

const MIGRATION_HINT = 'Faltan columnas/tablas del esquema integrado. Ejecuta database/instalacion.sql o las migraciones indicadas en README.md.';

class HttpError extends Error {
    constructor(status, message) {
        super(message);
        this.status = status;
    }
}

function describeDbError(err) {
    const errors = Array.isArray(err.errors) && err.errors.length ? err.errors : [err];
    const detail = errors.map(e => [e.code, e.address ? `${e.address}:${e.port}` : (e.sqlMessage || e.message)].filter(Boolean).join(' ')).join(' | ');
    const hints = {
        ECONNREFUSED: 'MySQL no está encendido o escucha en otro puerto.',
        ER_ACCESS_DENIED_ERROR: 'Usuario o contraseña de MySQL incorrectos; revisa pizzeria-backend/.env.',
        ER_BAD_DB_ERROR: 'La base de datos pizzeria_db no existe; ejecuta database/instalacion.sql.'
    };
    return `${detail}${hints[errors[0].code] ? `\n  → ${hints[errors[0].code]}` : ''}`;
}

function parseOrderId(value) {
    const id = Number(value);
    if (!Number.isInteger(id) || id <= 0) throw new HttpError(400, 'ID de pedido inválido.');
    return id;
}

// Reglas para el flujo compartido de pedidos.
function isValidTransition(order, nextStatus) {
    const isDelivery = order.order_type === 'DOMICILIO';
    switch (order.status) {
        case 'REGISTRADO': return nextStatus === 'EN_COCINA' || nextStatus === 'CANCELADO';
        case 'EN_COCINA': return nextStatus === 'LISTO';
        case 'LISTO': return isDelivery ? nextStatus === 'EN_REPARTO' : nextStatus === 'COMPLETADO';
        case 'EN_REPARTO': return nextStatus === 'COMPLETADO';
        default: return false;
    }
}

async function fetchOrdersWithItems(whereSql, orderSql) {
    const [orders] = await db.query(`
        SELECT o.*,
               CASE WHEN o.status = 'EN_COCINA' AND o.estimated_minutes IS NOT NULL
                    THEN TIMESTAMPDIFF(SECOND, NOW(), DATE_ADD(o.kitchen_started_at, INTERVAL o.estimated_minutes MINUTE)) END AS remaining_seconds,
               CASE WHEN o.status = 'EN_COCINA' AND o.oven_started_at IS NOT NULL
                    THEN TIMESTAMPDIFF(SECOND, o.oven_started_at, NOW()) END AS oven_elapsed_seconds
        FROM orders o WHERE ${whereSql} ORDER BY ${orderSql}`);
    if (!orders.length) return [];

    const [items] = await db.query(`
        SELECT oi.id, oi.order_id, oi.product_id, p.name AS product_name,
               oi.quantity, oi.unit_price, oi.subtotal, oi.notes
        FROM order_items oi LEFT JOIN products p ON p.id = oi.product_id
        WHERE oi.order_id IN (?) ORDER BY oi.id`, [orders.map(order => order.id)]);
    const byOrder = new Map();
    for (const item of items) {
        if (!byOrder.has(item.order_id)) byOrder.set(item.order_id, []);
        byOrder.get(item.order_id).push(item);
    }
    return orders.map(order => ({ ...order, items: byOrder.get(order.id) || [] }));
}

async function changeOrderStatus(id, nextStatus, { allowedFrom = null, estimatedMinutes = null } = {}) {
    const [rows] = await db.query('SELECT id, status, order_type FROM orders WHERE id = ?', [id]);
    if (!rows.length) throw new HttpError(404, 'Pedido no encontrado');
    const order = rows[0];
    if ((allowedFrom && !allowedFrom.includes(order.status)) || !isValidTransition(order, nextStatus)) {
        throw new HttpError(409, `No se puede cambiar el pedido #${id} de ${order.status} a ${nextStatus}.`);
    }
    const sets = ['status = ?'];
    const values = [nextStatus];
    if (nextStatus === 'EN_COCINA') sets.push('kitchen_started_at = NOW()', 'oven_started_at = NULL', 'estimated_minutes = ?'), values.push(estimatedMinutes);
    if (nextStatus === 'LISTO') sets.push('ready_at = NOW()');
    const [result] = await db.query(`UPDATE orders SET ${sets.join(', ')} WHERE id = ? AND status = ?`, [...values, id, order.status]);
    if (!result.affectedRows) throw new HttpError(409, 'El pedido cambió de estado mientras tanto. Actualiza e intenta de nuevo.');
    return { message: `Estado del pedido #${id} actualizado a ${nextStatus}` };
}

function parseEstimatedMinutes(value, required) {
    if (value === undefined || value === null || value === '') {
        if (required) throw new HttpError(400, 'estimated_minutes es obligatorio (minutos de preparación).');
        return null;
    }
    const minutes = Number(value);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 240) throw new HttpError(400, 'estimated_minutes debe ser un entero entre 1 y 240.');
    return minutes;
}

async function kitchenUpdate(id, sql, params, conflictMessage) {
    const [result] = await db.query(sql, params);
    if (result.affectedRows) return;
    const [rows] = await db.query('SELECT id FROM orders WHERE id = ?', [id]);
    if (!rows.length) throw new HttpError(404, 'Pedido no encontrado');
    throw new HttpError(409, conflictMessage);
}

app.get('/api/v1/health', async (req, res) => {
    await db.query('SELECT 1');
    res.json({ ok: true, database: 'connected' });
});

// ============================================
// OPERACIÓN DE COCINA
// ============================================

app.get('/api/v1/kitchen/orders', async (req, res) => {
    res.json(await fetchOrdersWithItems("o.status IN ('REGISTRADO', 'EN_COCINA')", 'o.created_at ASC, o.id ASC'));
});

app.patch('/api/v1/kitchen/orders/:id/start', async (req, res) => {
    const id = parseOrderId(req.params.id);
    const estimatedMinutes = parseEstimatedMinutes(req.body && req.body.estimated_minutes, true);
    res.json(await changeOrderStatus(id, 'EN_COCINA', { allowedFrom: ['REGISTRADO'], estimatedMinutes }));
});

app.patch('/api/v1/kitchen/orders/:id/oven', async (req, res) => {
    const id = parseOrderId(req.params.id);
    await kitchenUpdate(id,
        "UPDATE orders SET oven_started_at = NOW() WHERE id = ? AND status = 'EN_COCINA' AND oven_started_at IS NULL",
        [id], 'El pedido no está en preparación o ya está en el horno.');
    res.json({ message: `Pedido #${id} en el horno` });
});

app.patch('/api/v1/kitchen/orders/:id/ready', async (req, res) => {
    const id = parseOrderId(req.params.id);
    res.json(await changeOrderStatus(id, 'LISTO', { allowedFrom: ['EN_COCINA'] }));
});

app.patch('/api/v1/kitchen/orders/:id/back', async (req, res) => {
    const id = parseOrderId(req.params.id);
    const [rows] = await db.query('SELECT status, oven_started_at FROM orders WHERE id = ?', [id]);
    if (!rows.length) throw new HttpError(404, 'Pedido no encontrado');
    const order = rows[0];
    if (order.status === 'EN_COCINA' && order.oven_started_at) {
        await kitchenUpdate(id,
            "UPDATE orders SET oven_started_at = NULL WHERE id = ? AND status = 'EN_COCINA' AND oven_started_at IS NOT NULL",
            [id], 'El pedido cambió de estado mientras tanto. Actualiza e intenta de nuevo.');
        return res.json({ message: `Pedido #${id} regresó a preparación` });
    }
    if (order.status === 'EN_COCINA') {
        await kitchenUpdate(id,
            "UPDATE orders SET status = 'REGISTRADO', kitchen_started_at = NULL, estimated_minutes = NULL WHERE id = ? AND status = 'EN_COCINA' AND oven_started_at IS NULL",
            [id], 'El pedido cambió de estado mientras tanto. Actualiza e intenta de nuevo.');
        return res.json({ message: `Pedido #${id} regresó a pendiente` });
    }
    throw new HttpError(409, `El pedido #${id} está en ${order.status}; cocina no puede regresarlo.`);
});

// ============================================
// MANEJO DE ERRORES
// ============================================
app.use((req, res) => res.status(404).json({ error: 'Ruta no encontrada' }));
app.use((err, req, res, next) => {
    if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'El cuerpo de la petición no es JSON válido.' });
    if (err.code === 'ER_BAD_FIELD_ERROR' || err.code === 'ER_NO_SUCH_TABLE') {
        console.error(MIGRATION_HINT, err.message);
        return res.status(500).json({ error: MIGRATION_HINT });
    }
    console.error(err);
    res.status(500).json({ error: 'Error interno del servidor' });
});

app.listen(PORT, async () => {
    console.log(`Backend de Cocina corriendo en http://localhost:${PORT}`);
    try {
        await db.query('SELECT 1');
        console.log('Conectado exitosamente a MySQL.');
        const [columns] = await db.query(
            `SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'orders'`
        );
        const names = new Set(columns.map(column => column.COLUMN_NAME));
        const required = ['estimated_minutes', 'kitchen_started_at', 'oven_started_at', 'ready_at'];
        if (required.some(column => !names.has(column))) console.warn(MIGRATION_HINT);
    } catch (error) {
        console.error('No se pudo comprobar la base de datos:', describeDbError(error));
    }
});

process.on('SIGINT', async () => {
    await db.end();
    process.exit(0);
});
