# Backend de Cocina – Pizzería

API REST (Node.js + Express + MySQL) del módulo de **Cocina**: cola de pedidos, inicio de preparación con tiempo estimado, horno, listo y regreso de paso.

Es la parte del backend central (`pizzeria-backend`) que usa el front de cocina. **No incluye** las rutas de Clientes (cuentas, menú, pedidos) ni de Recepción.

> Cocina solo ve pedidos que ya existen en la base. Para que lleguen pedidos necesitas que Clientes o Recepción los creen en la misma `pizzeria_db` (con el backend completo o con el backend de clientes). Este paquete por sí solo no crea pedidos.

## Requisitos

- Node.js 18 o superior
- MySQL 8 o superior con la base `pizzeria_db` creada (script `database/instalacion.sql` del proyecto)

Tablas que usa: `orders`, `order_items` y `products`. `orders` necesita las columnas `estimated_minutes`, `kitchen_started_at`, `oven_started_at` y `ready_at`; el servidor avisa al arrancar si faltan.

## Instalación

```bash
cp .env.example .env     # y edita DB_PASSWORD con tu contraseña de MySQL
npm install
npm start
```

Al arrancar debe mostrar `Backend de Cocina corriendo en http://localhost:3000` y `Conectado exitosamente a MySQL.`

| Variable      | Valor por defecto | Descripción          |
| ------------- | ----------------- | -------------------- |
| `PORT`        | `3000`            | Puerto del servidor  |
| `DB_HOST`     | `127.0.0.1`       | Servidor MySQL       |
| `DB_PORT`     | `3306`            | Puerto MySQL         |
| `DB_USER`     | `root`            | Usuario MySQL        |
| `DB_PASSWORD` | (vacío)           | Contraseña MySQL     |
| `DB_NAME`     | `pizzeria_db`     | Nombre de la base    |

No subas `.env` al repositorio.

## Comprobar que funciona

<http://localhost:3000/api/v1/health> debe responder `{"ok":true,"database":"connected"}`.

## Endpoints

Base: `/api/v1`. Los errores tienen la forma `{ "error": "mensaje" }`. No requieren sesión.

| Método | Ruta                      | Descripción |
| ------ | ------------------------- | ----------- |
| GET    | `/health`                 | Estado del servidor y la base |
| GET    | `/kitchen/orders`         | Pedidos en cocina (estado `REGISTRADO` o `EN_COCINA`), del más antiguo al más nuevo, con sus `items` |
| PATCH  | `/kitchen/orders/:id/start` | Toma el pedido: `REGISTRADO` → `EN_COCINA`. Body: `{ "estimated_minutes": 20 }` (obligatorio, entero de 1 a 240) |
| PATCH  | `/kitchen/orders/:id/oven`  | Marca la entrada al horno (solo si está `EN_COCINA` y aún no está en el horno) |
| PATCH  | `/kitchen/orders/:id/ready` | `EN_COCINA` → `LISTO` |
| PATCH  | `/kitchen/orders/:id/back`  | Regresa un paso: del horno a preparación, o de preparación a pendiente |

### Qué devuelve `GET /kitchen/orders`
Cada pedido trae sus columnas de `orders` más:
- `remaining_seconds`: segundos que faltan del tiempo estimado (puede ser negativo si ya se pasó).
- `oven_elapsed_seconds`: segundos desde que entró al horno.
- `items`: `product_name`, `quantity`, `unit_price`, `subtotal` y `notes`.

### Respuestas de las acciones
- `200` con `{ "message": "..." }` si se aplicó.
- `400` si el id o `estimated_minutes` no son válidos.
- `404` si el pedido no existe.
- `409` si el pedido no está en un estado que permita la acción o cambió mientras tanto. Los cambios se hacen con comprobación del estado anterior, así que dos pantallas de cocina no se pisan.

## Flujo en cocina

| Paso en la pantalla | Estado en base | Campos que se llenan |
| ------------------- | -------------- | -------------------- |
| Pedido sin tomar    | `REGISTRADO`   | |
| Preparación         | `EN_COCINA`    | `kitchen_started_at`, `estimated_minutes` |
| Cocinando (horno)   | `EN_COCINA`    | `oven_started_at` |
| Listo               | `LISTO`        | `ready_at` |

A partir de `LISTO` el pedido pasa a Recepción (entrega o reparto).

## Front de cocina

El front (`FrontendPizzeria-feature-cocina`, React + Vite) se conecta por el proxy de Vite a `http://localhost:3000`. Si cambias `PORT`, ajusta el `target` en su `vite.config.js`.

## Problemas comunes

| Problema | Qué revisar |
| -------- | ----------- |
| `ECONNREFUSED` | MySQL apagado o `DB_HOST`/`DB_PORT` incorrectos. |
| `Access denied` | `DB_USER` / `DB_PASSWORD` en `.env`. |
| `Unknown database pizzeria_db` | Falta ejecutar `database/instalacion.sql`. |
| Aviso "Faltan columnas/tablas…" | Ejecuta `instalacion.sql` o `database/migraciones/001_tiempos_cocina.sql` y `002_horno_cocina.sql`. |
| La lista de cocina está vacía | No hay pedidos en `REGISTRADO` o `EN_COCINA`; créalos desde Clientes o Recepción. |
